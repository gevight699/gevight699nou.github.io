GÉNIE EN GUERRE - PROJET FINAL ICS3U

Comment ouvrir le jeu :
1. Dézippe le dossier.
2. Ouvre index.html dans Google Chrome.
3. Entre ton nom.
4. Choisis la difficulté et la catégorie.
5. Clique sur Démarrer la mission.

Structure du projet :
- index.html : page principale du jeu
- css/style.css : design complet du jeu
- scripts/script.js : logique JavaScript complète
- images/logo.png : logo du jeu
- documentation/cahier_contenu.md : contenu à utiliser dans le cahier des charges

Fonctionnalités :
- bataille navale 6x6
- 5 navires ennemis et 5 navires alliés
- questions de trivia après un tir réussi
- système de score
- frappe nucléaire après 3 bonnes réponses
- ordinateur qui contre-attaque
- formulaire interactif
- journal de bataille
