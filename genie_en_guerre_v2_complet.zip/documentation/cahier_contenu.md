# Cahier des charges - Génie en Guerre

## Description générale
Génie en Guerre est un jeu éducatif inspiré de la bataille navale. Le joueur doit trouver les navires ennemis sur une grille, mais les frappes spéciales dépendent de ses réponses à des questions de trivia. Le jeu combine stratégie, hasard et connaissances scolaires afin de rendre l’apprentissage plus interactif.

## Domaine éducatif
Culture générale et informatique ICS3U.

## Année d’études
Secondaire, surtout 10e à 11e année.

## Thème
Bataille navale, stratégie militaire fictive et questions de connaissances.

## Entrées
- Nom du joueur : input type text
- Difficulté : select
- Catégorie : radio buttons
- Bonus visuels : checkbox
- Cases de la grille : boutons cliquables
- Réponses de trivia : radio buttons
- Validation : bouton

## Sorties
- Score du joueur
- Nombre de navires restants
- Grilles visuelles
- Messages de rétroaction
- Journal de bataille
- État de la frappe nucléaire

## Fonctions principales du code
- nouvellePartie()
- creerGrilleVide()
- placerNavires()
- demarrerJeu()
- dessinerGrilles()
- attaquer()
- afficherQuestion()
- validerReponse()
- lancerNuke()
- tourOrdinateur()
- verifierFinPartie()

## Pseudocode résumé
DÉBUT
Créer les grilles du joueur et de l’ordinateur
Placer les navires au hasard
Demander le nom, la difficulté et la catégorie
TANT QUE la partie est active :
    Le joueur clique sur une case ennemie
    SI la case contient un navire :
        afficher Touché
        ajouter des points
        poser une question de trivia
        SI la réponse est bonne :
            charger la frappe nucléaire
    SINON :
        afficher Raté
    L’ordinateur attaque une case du joueur
    SI un joueur n’a plus de navires :
        terminer la partie
FIN

## Plan de travail / Gantt
| Tâche | Responsable | Durée estimée |
|---|---|---|
| Choix du concept | Groupe | 1 jour |
| Cahier des charges | Groupe | 2 jours |
| Design du logo | Gevorg | 1 jour |
| Structure HTML | Paul | 1 jour |
| Design CSS | Gevorg | 2 jours |
| Logique JavaScript | Amazir + Gevorg | 3 jours |
| Testing | Groupe | 1-2 jours |
| Documentation / vidéo | Groupe | 1 jour |

## Tests
| Test | Donnée utilisée | Résultat attendu |
|---|---|---|
| Nom vide | rien | message d’erreur |
| Nom valide | Gevorg | mission démarre |
| Clic sur case | case inconnue | touché ou raté |
| Bonne réponse | bonne option | +50 points et +1 charge nucléaire |
| Mauvaise réponse | mauvaise option | -25 points |
| Nuke prêt | 3/3 | bouton activé |
| Fin de partie | 0 navire restant | victoire ou défaite |

## Entretien
Améliorations possibles :
- Ajouter des sons.
- Ajouter plusieurs niveaux.
- Ajouter une minuterie.
- Ajouter un mode multijoueur.
- Ajouter plus de questions.
- Ajouter des navires de tailles différentes.
